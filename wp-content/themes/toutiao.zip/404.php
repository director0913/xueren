<?php get_header(); ?>

<div class="content-wrap">
	<div class="content">
		<?php hui_404() ?>
	</div>
</div>

<?php get_footer(); ?>